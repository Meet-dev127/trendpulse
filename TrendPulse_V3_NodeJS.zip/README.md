# TrendPulse V3 — Node.js

Real-time Twitter/X + Google + YouTube + Reddit + News trends.

## Quick Start
```bash
npm install
node server.js
# Open http://localhost:3000
```

## Deploy
Push to GitHub → Hostinger auto-deploys.

## API Endpoints
- GET /api/all?geo=US  — All platforms
- GET /api/twitter?geo=IN  — Twitter only  
- GET /health  — Server status
