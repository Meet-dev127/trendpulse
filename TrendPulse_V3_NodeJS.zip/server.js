// ═══════════════════════════════════════════════════════════
//  TrendPulse V3 — Node.js Express Server
//  Hostinger Node.js Web App deployment
//  Fetches: Twitter/X (trends24 scrape) + Google + YouTube + Reddit + News
//  Cache: In-memory (NodeCache) — 1 hour TTL
// ═══════════════════════════════════════════════════════════

const express    = require('express');
const fetch      = require('node-fetch');
const Parser     = require('rss-parser');
const NodeCache  = require('node-cache');
const compression= require('compression');
const cors       = require('cors');
const path       = require('path');
const fs         = require('fs');

const app   = express();
const cache = new NodeCache({ stdTTL: 3600, checkperiod: 300 }); // 1hr cache
const rss   = new Parser({ timeout: 8000, headers: { 'User-Agent': 'TrendPulse/3.0' } });

// ── CONFIG ─────────────────────────────────────────────────
const PORT    = process.env.PORT || 3000;
const CACHE_TTL = 3600; // 1 hour in seconds

// ── MIDDLEWARE ─────────────────────────────────────────────
app.use(compression());
app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// ── COUNTRY DATA ───────────────────────────────────────────
const TW_SLUG = {
  WW:'worldwide', US:'united-states', IN:'india', GB:'united-kingdom',
  CA:'canada', AU:'australia', DE:'germany', FR:'france', BR:'brazil',
  MX:'mexico', JP:'japan', KR:'south-korea', IT:'italy', ES:'spain',
  TR:'turkey', PH:'philippines', NG:'nigeria', ZA:'south-africa',
  EG:'egypt', AR:'argentina', ID:'indonesia', TH:'thailand', SA:'saudi-arabia',
  PK:'pakistan', SG:'singapore', MY:'malaysia', NL:'netherlands', SE:'sweden',
  PL:'poland', PT:'portugal', GR:'greece', UA:'ukraine', IL:'israel',
  AE:'united-arab-emirates', CO:'colombia', CL:'chile', KE:'kenya',
  MA:'morocco', RO:'romania', HK:'hong-kong', TW:'taiwan', VN:'vietnam',
};

const LANG = {
  US:'en-US', IN:'en-IN', GB:'en-GB', CA:'en-CA', AU:'en-AU',
  DE:'de-DE', FR:'fr-FR', BR:'pt-BR', MX:'es-MX', JP:'ja-JP',
  KR:'ko-KR', IT:'it-IT', ES:'es-ES', TR:'tr-TR', PH:'en-PH',
  NG:'en-NG', ZA:'en-ZA', EG:'ar-EG', AR:'es-AR', ID:'id-ID',
  TH:'th-TH', SA:'ar-SA', PK:'ur-PK', SG:'en-SG', MY:'ms-MY',
  NL:'nl-NL', SE:'sv-SE', PL:'pl-PL', PT:'pt-PT', GR:'el-GR',
  UA:'uk-UA', IL:'he-IL', AE:'ar-AE', CO:'es-CO', CL:'es-CL',
  VN:'vi-VN', MA:'ar-MA',
};

// ── PROXY FETCH ────────────────────────────────────────────
async function proxyFetch(url) {
  const proxies = [
    `https://api.allorigins.win/get?url=${encodeURIComponent(url)}`,
    `https://corsproxy.io/?url=${encodeURIComponent(url)}`,
  ];
  for (const proxy of proxies) {
    try {
      const res = await fetch(proxy, {
        timeout: 9000,
        headers: { 'User-Agent': 'TrendPulse/3.0' }
      });
      if (proxy.includes('allorigins')) {
        const json = await res.json();
        if (json.contents) return json.contents;
      } else {
        return await res.text();
      }
    } catch (e) { /* try next */ }
  }
  throw new Error('All proxies failed for: ' + url);
}

// ── TWITTER/X via trends24.in scraping ────────────────────
async function fetchTwitter(geo) {
  const cacheKey = `twitter:${geo}`;
  const cached = cache.get(cacheKey);
  if (cached) return cached;

  const slug = TW_SLUG[geo] || 'worldwide';

  // Strategy 1: Scrape trends24.in (they do the Twitter scraping for us)
  try {
    const html = await proxyFetch(`https://trends24.in/${slug}/`);

    // Parse hourly timeline columns from trends24.in HTML
    const columns = [];

    // Match time headers + trend blocks
    const timeBlocks = html.split(/class="[^"]*trend-card[^"]*"/);

    // Extract all Twitter search links with their text
    const tweetLinks = [...html.matchAll(
      /href="(https:\/\/twitter\.com\/search\?q=[^"]+)"[^>]*>\s*([^<]+)\s*<\/a>/g
    )];

    // Extract approximate tweet volumes
    const volumes = [...html.matchAll(/class="[^"]*tweet-count[^"]*"[^>]*>([^<]+)<\/span>/g)];

    // Extract timestamps from the page
    const timestamps = [...html.matchAll(
      /(\d+\s+(?:hour|minute)s?\s+ago|Just\s+now|\d+h\s+ago)/gi
    )];

    if (tweetLinks.length > 5) {
      // Group into hourly columns (trends24 shows ~50 trends per hour across time)
      const trendsPerHour = Math.ceil(tweetLinks.length / 8);
      const now = new Date();

      for (let h = 0; h < 8 && h * trendsPerHour < tweetLinks.length; h++) {
        const hourTrends = tweetLinks.slice(h * trendsPerHour, (h + 1) * trendsPerHour);
        const timeLabel = h === 0 ? 'Just now' : `${h} hour${h > 1 ? 's' : ''} ago`;
        const ts = new Date(now - h * 3600000);
        const hr = ts.getHours(), ap = hr >= 12 ? 'PM' : 'AM', h12 = hr % 12 || 12;

        columns.push({
          time: timeLabel,
          timestamp: `${h12}:00 ${ap}`,
          trends: hourTrends.map((m, i) => {
            const rawQuery = decodeURIComponent(m[1].replace('https://twitter.com/search?q=', ''));
            const name = m[2].trim();
            const isHash = rawQuery.startsWith('#') || name.startsWith('#');
            return {
              rank: i + 1,
              name: name,
              link: m[1],
              volume: '',
              isHashtag: isHash,
            };
          })
        });
      }

      if (columns.length > 0) {
        cache.set(cacheKey, columns);
        return columns;
      }
    }
  } catch (e) {
    console.warn('trends24 scrape failed:', e.message);
  }

  // Strategy 2: Google Trends as Twitter-formatted fallback
  try {
    const gtData = await fetchGoogle(geo);
    if (gtData.length) {
      cache.set(cacheKey, gtData);
      return gtData;
    }
  } catch (e) {}

  return [];
}

// ── GOOGLE TRENDS RSS ──────────────────────────────────────
async function fetchGoogle(geo) {
  const cacheKey = `google:${geo}`;
  const cached = cache.get(cacheKey);
  if (cached) return cached;

  const code = geo === 'WW' ? '' : geo;
  const url = code
    ? `https://trends.google.com/trending/rss?geo=${code}`
    : `https://trends.google.com/trending/rss`;

  try {
    const xml = await proxyFetch(url);
    const feed = await rss.parseString(xml);
    const now = new Date();

    const data = [{
      time: 'Latest',
      timestamp: now.toLocaleTimeString('en', { hour: '2-digit', minute: '2-digit' }),
      trends: feed.items.slice(0, 25).map((item, i) => ({
        rank: i + 1,
        name: item.title,
        link: `https://www.google.com/search?q=${encodeURIComponent(item.title)}`,
        volume: item['ht:approx_traffic'] ? `~${item['ht:approx_traffic']} searches` : '',
        isHashtag: false,
      }))
    }];

    cache.set(cacheKey, data);
    return data;
  } catch (e) {
    console.warn('Google Trends failed:', e.message);
    return [];
  }
}

// ── YOUTUBE (via Google News RSS) ─────────────────────────
async function fetchYouTube(geo) {
  const cacheKey = `youtube:${geo}`;
  const cached = cache.get(cacheKey);
  if (cached) return cached;

  const code = geo === 'WW' ? 'US' : geo;

  try {
    const url = `https://news.google.com/rss/search?q=site:youtube.com&hl=en&gl=${code}&ceid=${code}:en`;
    const xml = await proxyFetch(url);
    const feed = await rss.parseString(xml);
    const now = new Date();

    const data = [{
      time: 'Latest',
      timestamp: now.toLocaleTimeString('en', { hour: '2-digit', minute: '2-digit' }),
      trends: feed.items.slice(0, 15).map((item, i) => ({
        rank: i + 1,
        name: item.title.replace(/\s*[-–]\s*YouTube\s*$/i, '').trim(),
        link: item.link || `https://youtube.com/results?search_query=${encodeURIComponent(item.title)}`,
        volume: item.source?.title || 'YouTube',
        isHashtag: false,
      })).filter(t => t.name.length > 3)
    }];

    cache.set(cacheKey, data);
    return data;
  } catch (e) {
    console.warn('YouTube failed:', e.message);
    return [];
  }
}

// ── REDDIT ─────────────────────────────────────────────────
async function fetchReddit(geo) {
  const cacheKey = `reddit:${geo}`;
  const cached = cache.get(cacheKey);
  if (cached) return cached;

  try {
    const res = await fetch('https://www.reddit.com/r/all/hot.json?limit=25', {
      headers: { 'User-Agent': 'TrendPulse/3.0' },
      timeout: 7000
    });
    const json = await res.json();
    const now = new Date();

    const data = [{
      time: 'Latest',
      timestamp: now.toLocaleTimeString('en', { hour: '2-digit', minute: '2-digit' }),
      trends: json.data.children.slice(0, 20).map((p, i) => ({
        rank: i + 1,
        name: p.data.title.length > 70 ? p.data.title.slice(0, 70) + '…' : p.data.title,
        link: `https://www.reddit.com${p.data.permalink}`,
        volume: `r/${p.data.subreddit} · ${p.data.score.toLocaleString()} upvotes`,
        isHashtag: false,
      }))
    }];

    cache.set(cacheKey, data);
    return data;
  } catch (e) {
    console.warn('Reddit failed:', e.message);
    return [];
  }
}

// ── NEWS (Google News RSS) ─────────────────────────────────
async function fetchNews(geo) {
  const cacheKey = `news:${geo}`;
  const cached = cache.get(cacheKey);
  if (cached) return cached;

  const code = geo === 'WW' ? 'US' : geo;
  const lang = LANG[code] || 'en-US';

  try {
    const url = `https://news.google.com/rss?hl=${lang}&gl=${code}&ceid=${code}:${lang.split('-')[0]}`;
    const xml = await proxyFetch(url);
    const feed = await rss.parseString(xml);
    const now = new Date();

    const data = [{
      time: 'Latest',
      timestamp: now.toLocaleTimeString('en', { hour: '2-digit', minute: '2-digit' }),
      trends: feed.items.slice(0, 20).map((item, i) => ({
        rank: i + 1,
        name: item.title,
        link: item.link || '#',
        volume: item.source?.title || '',
        isHashtag: false,
      })).filter(t => t.name)
    }];

    cache.set(cacheKey, data);
    return data;
  } catch (e) {
    console.warn('News failed:', e.message);
    return [];
  }
}

// ══════════════════════════════════════════════════════════
//  API ROUTES
// ══════════════════════════════════════════════════════════

// Health check — Hostinger checks this
app.get('/health', (req, res) => {
  res.json({
    status: 'ok',
    app: 'TrendPulse V3',
    uptime: Math.floor(process.uptime()),
    cached: cache.keys().length + ' items',
    ts: new Date().toISOString()
  });
});

// Geo detection from request IP
app.get('/api/geo', async (req, res) => {
  try {
    const ip = req.headers['x-forwarded-for']?.split(',')[0] ||
                req.headers['x-real-ip'] ||
                req.socket.remoteAddress ||
                '';
    // Call free IP geolocation
    const geoRes = await fetch(`https://ip-api.com/json/${ip}?fields=status,country,countryCode,regionName,city`, { timeout: 4000 });
    const geo = await geoRes.json();
    if (geo.status === 'success') {
      res.json({ country: geo.countryCode, name: geo.country, region: geo.regionName, city: geo.city });
    } else {
      res.json({ country: 'WW', name: 'Worldwide' });
    }
  } catch (e) {
    res.json({ country: 'WW', name: 'Worldwide' });
  }
});

// Twitter/X trends
app.get('/api/twitter', async (req, res) => {
  const geo = (req.query.geo || 'WW').toUpperCase();
  try {
    const data = await fetchTwitter(geo);
    res.json({ success: true, geo, data, fetchedAt: new Date().toISOString() });
  } catch (e) {
    res.status(500).json({ success: false, error: e.message });
  }
});

// Google Trends
app.get('/api/google', async (req, res) => {
  const geo = (req.query.geo || 'WW').toUpperCase();
  try {
    const data = await fetchGoogle(geo);
    res.json({ success: true, geo, data, fetchedAt: new Date().toISOString() });
  } catch (e) {
    res.status(500).json({ success: false, error: e.message });
  }
});

// YouTube
app.get('/api/youtube', async (req, res) => {
  const geo = (req.query.geo || 'US').toUpperCase();
  try {
    const data = await fetchYouTube(geo);
    res.json({ success: true, geo, data, fetchedAt: new Date().toISOString() });
  } catch (e) {
    res.status(500).json({ success: false, error: e.message });
  }
});

// Reddit
app.get('/api/reddit', async (req, res) => {
  const geo = (req.query.geo || 'WW').toUpperCase();
  try {
    const data = await fetchReddit(geo);
    res.json({ success: true, geo, data, fetchedAt: new Date().toISOString() });
  } catch (e) {
    res.status(500).json({ success: false, error: e.message });
  }
});

// News
app.get('/api/news', async (req, res) => {
  const geo = (req.query.geo || 'WW').toUpperCase();
  try {
    const data = await fetchNews(geo);
    res.json({ success: true, geo, data, fetchedAt: new Date().toISOString() });
  } catch (e) {
    res.status(500).json({ success: false, error: e.message });
  }
});

// ALL platforms at once — main endpoint used by the frontend
app.get('/api/all', async (req, res) => {
  const geo = (req.query.geo || 'WW').toUpperCase();

  const [tw, g, yt, r, n] = await Promise.allSettled([
    fetchTwitter(geo),
    fetchGoogle(geo),
    fetchYouTube(geo),
    fetchReddit(geo),
    fetchNews(geo),
  ]);

  res.json({
    success: true,
    geo,
    fetchedAt: new Date().toISOString(),
    twitter:  tw.status === 'fulfilled' ? tw.value : [],
    google:   g.status  === 'fulfilled' ? g.value  : [],
    youtube:  yt.status === 'fulfilled' ? yt.value : [],
    reddit:   r.status  === 'fulfilled' ? r.value  : [],
    news:     n.status  === 'fulfilled' ? n.value  : [],
  });
});

// Clear cache (admin endpoint — protect in production)
app.post('/api/cache/clear', (req, res) => {
  cache.flushAll();
  res.json({ success: true, message: 'Cache cleared' });
});

// ── SERVE FRONTEND ─────────────────────────────────────────
// All other routes → serve the main HTML (SPA)
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// ── START SERVER ───────────────────────────────────────────
app.listen(PORT, () => {
  console.log(`✅ TrendPulse V3 running on port ${PORT}`);
  console.log(`📊 API: http://localhost:${PORT}/api/all?geo=US`);
  console.log(`❤️  Health: http://localhost:${PORT}/health`);
});

module.exports = app;
